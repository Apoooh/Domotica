﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Configuration;
using System.Drawing;

namespace Domotica.restricted
{
    public partial class WebDashboard : System.Web.UI.Page
    {
        static OleDbConnection conn = new OleDbConnection();

        private void button_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string WebsiteURL = "";


            conn.ConnectionString = ConfigurationManager.ConnectionStrings["Webdashboardconn"].ToString();
            OleDbCommand cmd = new OleDbCommand();
            try
            {
                conn.Open();
                cmd.CommandText = $"SELECT WebsiteURL FROM Websites WHERE ID = {btn.ID}";
                cmd.Connection = conn;
                OleDbDataReader reader = cmd.ExecuteReader();
                foreach (object o in reader)
                {
                    WebsiteURL = reader["WebsiteURL"].ToString();
                }
            }
            finally
            {
                conn.Close();
                if (!WebsiteURL.StartsWith("http://"))
                {
                    WebsiteURL = "http://" + WebsiteURL;
                }
                try
                {
                    System.Diagnostics.Process.Start(WebsiteURL);
                }
                catch
                {
                }
                }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["Webdashboardconn"].ToString();
            OleDbCommand cmd = new OleDbCommand();
            try
            {
                conn.Open();
                cmd.CommandText = $"SELECT * FROM Websites WHERE User = ? ORDER BY Naam";
                OleDbParameter param = new OleDbParameter();
                param.Value = User.Identity.Name;
                cmd.Parameters.Add(param);
                cmd.Connection = conn;
                OleDbDataReader reader = cmd.ExecuteReader();
                foreach (object o in reader)
                {
                    Button b = new Button();
                    b.ID = reader["id"].ToString();
                    b.Text = reader["Naam"].ToString();
                    b.Width = b.Height = 200;
                    b.BackColor = Color.FromName(reader["Color"].ToString());
                    b.Font.Size = 20;
                    b.Click += new EventHandler(button_Click);
                    pnlButtons.Controls.Add(b);
                }
            }
            finally
            {
                conn.Close();
            }
        }

        protected void btnLoguit_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["WachtwoordCookie"] != null)
            {
                Response.Cookies["WachtwoordCookie"].Expires = DateTime.Now.AddDays(-1);
            }
            Server.Transfer("../Home.aspx", true);
        }
    }
}