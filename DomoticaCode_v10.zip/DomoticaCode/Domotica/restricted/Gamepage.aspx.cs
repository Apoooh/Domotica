﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Domotica.restricted.Application_Files
{
    public partial class Gamepage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }


        protected void ddlGames_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        protected void adsGames_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            mvGames.ActiveViewIndex = int.Parse(ddlGames.SelectedValue);
        }

        protected void btnLoguit_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["WachtwoordCookie"] != null)
            {
                Response.Cookies["WachtwoordCookie"].Expires = DateTime.Now.AddDays(-1);
            }
            Server.Transfer("../Home.aspx", true);
        }
    }
}