﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Configuration;

namespace Domotica
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        static OleDbConnection conn = new OleDbConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                conn.ConnectionString = ConfigurationManager.ConnectionStrings["Webdashboard"].ToString();
            }

        }

        protected void TxtSubject_TextChanged(object sender, EventArgs e)
        {

        }


        protected void TxtName_TextChanged(object sender, EventArgs e)
        {

        }


        protected void btnSubmit_Click1(object sender, EventArgs e)
        {
            OleDbCommand cmd = new OleDbCommand();

            {

                cmd.CommandText = "INSERT INTO Contact ( [Naam], Email, Onderwerp, Bericht )"
                    + "SELECT ? AS Expr1, ? AS Expr2, ? AS Expr3, ? AS Expr4;";
                cmd.Parameters.Add("@Naam", OleDbType.VarChar, 128).Value = TxtName.Text;
                cmd.Parameters.Add("@Email", OleDbType.VarChar, 128).Value = TxtEmail.Text;
                cmd.Parameters.Add("@Onderwerp", OleDbType.VarChar, 128).Value = TxtSubject.Text;
                cmd.Parameters.Add("@Bericht", OleDbType.VarChar, 128).Value = TxtComments.Text;


            }
            try
            {
                conn.Open();
                cmd.Connection = conn;
                cmd.ExecuteNonQuery();
            }
            finally
            {
                conn.Close();
            }
            if (this.Page.User.Identity.IsAuthenticated)
            {
                Response.Redirect("restricted/Dashboard.aspx");
            }
            else
            {
                Response.Redirect("Home.aspx");
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            TxtComments.Text = "";
            TxtEmail.Text = "";
            TxtName.Text = "";
            TxtSubject.Text = "";
        }

        protected void btnGaTerug_Click(object sender, EventArgs e)
        {
            if (this.Page.User.Identity.IsAuthenticated)
            {
                Response.Redirect("restricted/Dashboard.aspx");
            }
            else
            {
                Response.Redirect("Home.aspx");
            }
        }
    }
}